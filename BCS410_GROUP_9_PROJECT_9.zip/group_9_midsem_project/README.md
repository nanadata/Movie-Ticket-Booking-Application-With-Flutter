# Group 9 Cinema Bookings — Movie Ticket Booking App

**BCS 410 — Mobile Application Development**
Accra Technical University | BTech Top-Up Computer Science, Year III (Weekend)
Mid-Semester Practical Project — **Project 9: Movie Ticket Booking App**

## Overview

Group 9 Cinema Bookings is a Flutter mobile application that lets a customer book movie tickets. From a welcoming home screen the user proceeds to a booking form, enters their name, phone number, and movie title (or picks one from suggestions), and selects the number of tickets required. On submission, the app validates the input and navigates to a booking summary screen showing all details, including the calculated total price.

## Features

### Home Screen
- **Welcome screen** introducing the app, with a **Book Tickets** button that opens the booking form.
- **View Members** button (top-left) opens a dialog listing all Group 9 members and their index numbers.

### Booking Form Screen
- **Home** button (top-left) returns to the home screen at any time, clearing the navigation stack.
- **Name entry** — validated text field that accepts letters, spaces, hyphens, and apostrophes only (no digits).
- **Phone Number entry** — validated text field that must start with `0` and contain exactly 10 digits (e.g. `0551736601`); non-digit characters are blocked as you type.
- **Movie Title** — an `Autocomplete` field that lets the user either:
  - pick a title from a built-in list of suggested movies, or
  - type in a custom/preferred movie title freely.
- **Number of Tickets** — can be set two ways:
  - typed directly into the field, or
  - adjusted using `+` / `−` stepper buttons (clamped between 1 and 25 tickets).
- **Live price preview** — shows the running total (tickets × price) as the form is filled in.
- **Fixed ticket price** — GH₵ 50.00 per ticket.
- **Form validation** — ensures name, phone number, movie title, and ticket count are all valid before booking.

### Booking Summary Screen
- **Home** button (top-left) returns to the home screen, clearing the navigation stack.
- Displays name, phone number, movie title, number of tickets, and total price.
- **Book Another Ticket** button loads a fresh, refreshed booking form (all fields reset) so the user can make a new booking.

### Themed UI
- Dark cinema-inspired theme (deep purple/navy gradient background) with red and gold accent colors, rounded cards, and Material 3 styling throughout all screens.

## Project Structure

```
group_9_cinema_bookings/
├── lib/
│   └── main.dart              # App entry point, home, booking form, and summary screens
├── test/
│   └── widget_test.dart       # Widget/smoke tests for the app
├── pubspec.yaml                # Project dependencies and metadata
└── README.md                   # This file
```

## Requirements

- [Flutter SDK](https://docs.flutter.dev/get-started/install) (3.x or later)
- Dart SDK (bundled with Flutter, >=3.0.0)
- Android Studio / VS Code with Flutter & Dart plugins (recommended)
- An emulator, simulator, or physical device for testing

## Getting Started

1. **Create a new Flutter project** (if not already created):
   ```bash
   flutter create group_9_cinema_bookings
   cd group_9_cinema_bookings
   ```

2. **Replace the generated files** with the ones provided:
   - Copy `main.dart` into `lib/main.dart` (overwrite the default file).
   - Copy `pubspec.yaml` into the project root (overwrite the default file).
   - Copy `widget_test.dart` into `test/widget_test.dart` (overwrite the default file).

3. **Install dependencies**:
   ```bash
   flutter pub get
   ```

4. **Run the app**:
   ```bash
   flutter run
   ```

5. **Run the tests** (optional):
   ```bash
   flutter test
   ```

## How to Use

1. Launch the app to see the **Group 9 Cinema Bookings** home screen.
2. Tap **View Members** to see the full list of Group 9 members, or tap **Book Tickets** to start a booking.
3. On the booking form, enter your **name** (letters only).
4. Enter your **phone number** — must start with `0` and be exactly 10 digits, e.g. `0551736601`.
5. Enter the **movie title** — start typing to see suggestions (including titles like *Students of ATU*), tap one to select it, or simply finish typing your own preferred title.
6. Set the **number of tickets** — type a number directly, or use the `+` / `−` buttons (up to 25 tickets).
7. Review the live **total price** shown on the form (GH₵ 50.00 per ticket).
8. Tap **Book Ticket**.
9. View the **Booking Summary** screen with your full booking details (name, phone number, movie title, tickets, total cost).
10. Tap **Home** to return to the welcome screen, or **Book Another Ticket** to start a fresh booking.

## Technical Notes

- Built entirely with Flutter's core `material.dart` and `services.dart` widgets — no external packages beyond `cupertino_icons` are required.
- Uses `StatelessWidget` for the Home and Booking Summary screens, and `StatefulWidget` for the booking form to manage controllers and form state.
- Uses `Form` and `TextFormField` with `validator` functions and `inputFormatters` (`FilteringTextInputFormatter`, `LengthLimitingTextInputFormatter`) for input validation and restriction.
- Name field is restricted to letters, spaces, hyphens, and apostrophes via a regex input formatter and validator.
- Phone number field is restricted to digits only, capped at 10 characters, and validated against the pattern `^0[0-9]{9}$`.
- Uses `Autocomplete<String>` for the flexible movie-title input.
- Uses `Navigator.push` / `Navigator.pushReplacement` / `Navigator.pushAndRemoveUntil` with `MaterialPageRoute` to move between the Home, Booking Form, and Booking Summary screens and pass booking data along.
- Price per ticket is defined as a constant (`pricePerTicket = 50.0`) so it is easy to adjust if required.
- Ticket count is bounded between `minTickets = 1` and `maxTickets = 25`.

## Author
Mobile Application Development Group 9 Members
Submitted for BCS 410 — Mobile Application Development, Mid-Semester Examination, 2025/2026.