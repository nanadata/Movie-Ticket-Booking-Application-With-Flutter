package com.example.midsem_trial

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
