import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const MovieTicketApp());
}

class MovieTicketApp extends StatelessWidget {
  const MovieTicketApp({super.key});

  @override
  Widget build(BuildContext context) {
    const Color primaryRed = Color(0xFFB71C1C);
    const Color gold = Color(0xFFE4A11B);

    return MaterialApp(
      title: 'Group 9 - Cinema Bookings',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF141221),
        colorScheme: ColorScheme.fromSeed(
          seedColor: primaryRed,
          brightness: Brightness.dark,
          primary: primaryRed,
          secondary: gold,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF211D34),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Colors.transparent),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: gold, width: 2),
          ),
          labelStyle: const TextStyle(color: Colors.white70),
          hintStyle: const TextStyle(color: Colors.white38),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

/// -------------------- HOME SCREEN --------------------
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final gold = Theme.of(context).colorScheme.secondary;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A1530), Color(0xFF141221), Color(0xFF1B0F16)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Align(
                  alignment: Alignment.topLeft,
                  child: TextButton.icon(
                    onPressed: () => _showMembersDialog(context, gold),
                    style: TextButton.styleFrom(
                      foregroundColor: gold,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 4, vertical: 4),
                    ),
                    icon: const Icon(Icons.groups_outlined, size: 20),
                    label: const Text(
                      'View Members',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [gold, const Color(0xFFB71C1C)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: gold.withOpacity(0.4),
                        blurRadius: 24,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.local_movies,
                      size: 56, color: Colors.white),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Welcome to\nGroup 9 Cinema Bookings App',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 1.1,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Book your favorite movies in seconds and enjoy the show!',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60, fontSize: 15),
                ),
                const SizedBox(height: 40),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const BookingFormScreen(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: gold,
                      foregroundColor: const Color(0xFF1A1530),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 6,
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.confirmation_num_outlined),
                        SizedBox(width: 10),
                        Text(
                          'Book Tickets',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showMembersDialog(BuildContext context, Color gold) {
    const members = [
      'Buabeng Otoo Derrick - 01259610B',
      'Boadu Marvellous Anim Kofi - 01259170B',
      'Asamoah Clifford Oppong - 01255433B',
      'Ankrah Isaac - 01259130B',
      'Adagba Felix Kweku - 01251624B',
      'Asare Richmond Kwesi - 01255065B',
    ];

    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          backgroundColor: const Color(0xFF211D34),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Icon(Icons.groups_outlined, color: gold, size: 26),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'GROUP 9 MEMBERS',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                ...members.map(
                  (member) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.person_outline,
                            color: gold.withOpacity(0.8), size: 18),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            member,
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: gold,
                      foregroundColor: const Color(0xFF1A1530),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: const Text(
                      'Close',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// -------------------- BOOKING FORM SCREEN --------------------
class BookingFormScreen extends StatefulWidget {
  const BookingFormScreen({super.key});

  @override
  State<BookingFormScreen> createState() => _BookingFormScreenState();
}

class _BookingFormScreenState extends State<BookingFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _movieController = TextEditingController();
  final _ticketController = TextEditingController(text: '1');

  static const double pricePerTicket = 50.0;
  static const int minTickets = 1;
  static const int maxTickets = 25;

  final List<String> _movieTitles = const [
    'Mobile App Development',
    'Avengers: Legacy',
    "Ocean's Mystery",
    'Students of ATU',
    'The Last Journey',
    'Shadow Hunter',
    'Love in Accra',
    'Kumasi Nights',
    'The Great Escape',
    'Silent Storm',
    'City of Dreams',
    'Beyond the Stars',
  ];

  int get _ticketCount => int.tryParse(_ticketController.text) ?? 0;

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _movieController.dispose();
    _ticketController.dispose();
    super.dispose();
  }

  void _goHome() {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const HomeScreen()),
      (route) => false,
    );
  }

  void _changeTicketCount(int delta) {
    setState(() {
      int current = int.tryParse(_ticketController.text) ?? minTickets;
      int updated = (current + delta).clamp(minTickets, maxTickets);
      _ticketController.text = updated.toString();
      _ticketController.selection = TextSelection.fromPosition(
        TextPosition(offset: _ticketController.text.length),
      );
    });
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final tickets = _ticketCount;
      final total = tickets * pricePerTicket;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => BookingSummaryScreen(
            name: _nameController.text.trim(),
            phoneNumber: _phoneController.text.trim(),
            movieTitle: _movieController.text.trim(),
            ticketCount: tickets,
            pricePerTicket: pricePerTicket,
            totalPrice: total,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final gold = Theme.of(context).colorScheme.secondary;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A1530), Color(0xFF141221), Color(0xFF1B0F16)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 2),
                  Align(
                    alignment: Alignment.topLeft,
                    child: TextButton.icon(
                      onPressed: _goHome,
                      style: TextButton.styleFrom(
                        foregroundColor: gold,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 4),
                      ),
                      icon: const Icon(Icons.home_outlined, size: 25),
                      label: const Text(
                        'Home',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [gold, const Color(0xFFB71C1C)],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: gold.withOpacity(0.4),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.local_movies,
                          size: 38, color: Colors.white),
                    ),
                  ),
                  const SizedBox(height: 3),
                  const Center(
                    child: Text(
                      'Group 9 Cinema Bookings',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 2),
                  const Center(
                    child: Text(
                      'Book your movie tickets in seconds and enjoy the show!',
                      style: TextStyle(color: Colors.white60, fontSize: 14),
                    ),
                  ),
                  const SizedBox(height: 7),

                  _sectionLabel('Your Name'),
                  const SizedBox(height: 2),
                  TextFormField(
                    controller: _nameController,
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.name,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(
                          RegExp(r"[a-zA-Z\s'\-]")),
                    ],
                    decoration: const InputDecoration(
                      hintText: 'e.g. Derrick Buabeng Otoo',
                      prefixIcon: Icon(Icons.person_outline, color: Colors.white54),
                    ),
                    validator: (value) {
                      final trimmed = value?.trim() ?? '';
                      if (trimmed.isEmpty) {
                        return 'Please enter your name';
                      }
                      if (!RegExp(r"^[a-zA-Z\s'\-]+$").hasMatch(trimmed)) {
                        return 'Name can only contain letters';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 7),

                  _sectionLabel('Phone Number'),
                  const SizedBox(height: 3),
                  TextFormField(
                    controller: _phoneController,
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.number,
                    maxLength: 10,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(10),
                    ],
                    decoration: const InputDecoration(
                      counterText: '',
                      hintText: 'e.g. 0551736601',
                      prefixIcon: Icon(Icons.phone_outlined, color: Colors.white54),
                    ),
                    validator: (value) {
                      final trimmed = value?.trim() ?? '';
                      if (trimmed.isEmpty) {
                        return 'Please enter your phone number';
                      }
                      if (!RegExp(r'^0[0-9]{9}$').hasMatch(trimmed)) {
                        return 'Enter a valid 10-digit number starting with 0';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 8),

                  _sectionLabel('Movie Title'),
                  const SizedBox(height: 5),
                  _buildMovieAutocomplete(),
                  const SizedBox(height: 8),

                  _sectionLabel('Number of Tickets'),
                  const SizedBox(height: 5),
                  _buildTicketStepper(gold),
                  const SizedBox(height: 8),

                  _buildPricePreview(gold),
                  const SizedBox(height: 8),

                  SizedBox(
                    height: 45,
                    child: ElevatedButton(
                      onPressed: _submit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: gold,
                        foregroundColor: const Color(0xFF1A1530),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 6,
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.confirmation_num_outlined),
                          SizedBox(width: 10),
                          Text(
                            'Book Ticket',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 13,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
        ),
      );

  /// Movie title field: type freely OR pick from suggested list.
  Widget _buildMovieAutocomplete() {
    return Autocomplete<String>(
      optionsBuilder: (TextEditingValue textEditingValue) {
        _movieController.text = textEditingValue.text;
        if (textEditingValue.text.isEmpty) {
          return _movieTitles;
        }
        return _movieTitles.where((title) => title
            .toLowerCase()
            .contains(textEditingValue.text.toLowerCase()));
      },
      onSelected: (String selection) {
        _movieController.text = selection;
      },
      fieldViewBuilder:
          (context, controller, focusNode, onFieldSubmitted) {
        // keep our controller in sync
        controller.addListener(() {
          _movieController.text = controller.text;
        });
        return TextFormField(
          controller: controller,
          focusNode: focusNode,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Type or pick a movie title',
            prefixIcon: Icon(Icons.theaters_outlined, color: Colors.white54),
            suffixIcon: Icon(Icons.arrow_drop_down, color: Colors.white54),
          ),
          validator: (value) {
            if (value == null || value.trim().isEmpty) {
              return 'Please enter or select a movie title';
            }
            return null;
          },
        );
      },
      optionsViewBuilder: (context, onSelected, options) {
        return Align(
          alignment: Alignment.topLeft,
          child: Material(
            color: const Color(0xFF211D34),
            elevation: 8,
            borderRadius: BorderRadius.circular(14),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 220, minWidth: 280),
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(vertical: 6),
                shrinkWrap: true,
                itemCount: options.length,
                itemBuilder: (context, index) {
                  final option = options.elementAt(index);
                  return ListTile(
                    leading: const Icon(Icons.local_movies_outlined,
                        color: Colors.white54, size: 20),
                    title: Text(option,
                        style: const TextStyle(color: Colors.white)),
                    onTap: () => onSelected(option),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  /// Ticket count: type directly OR use +/- buttons.
  Widget _buildTicketStepper(Color gold) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 1),
      decoration: BoxDecoration(
        color: const Color(0xFF211D34),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          _stepperButton(
            icon: Icons.remove,
            color: gold,
            onTap: () => _changeTicketCount(-1),
          ),
          Expanded(
            child: TextFormField(
              controller: _ticketController,
              textAlign: TextAlign.center,
              keyboardType: TextInputType.number,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
              decoration: const InputDecoration(
                border: InputBorder.none,
                filled: false,
                hintText: '1',
              ),
              onChanged: (_) => setState(() {}),
              validator: (value) {
                final n = int.tryParse(value ?? '');
                if (n == null || n < minTickets) {
                  return 'Enter at least $minTickets ticket';
                }
                if (n > maxTickets) {
                  return 'Max $maxTickets tickets';
                }
                return null;
              },
            ),
          ),
          _stepperButton(
            icon: Icons.add,
            color: gold,
            onTap: () => _changeTicketCount(1),
          ),
        ],
      ),
    );
  }

  Widget _stepperButton({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
    );
  }

  Widget _buildPricePreview(Color gold) {
    final tickets = _ticketCount.clamp(0, maxTickets);
    final total = tickets * pricePerTicket;
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [gold.withOpacity(0.18), const Color(0xFFB71C1C).withOpacity(0.18)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: gold.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Price per ticket: GH₵ 50.00',
              style: TextStyle(color: Colors.white70, fontSize: 13)),
          Text(
            'Total: GH₵ ${total.toStringAsFixed(2)}',
            style: TextStyle(
              color: gold,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

/// -------------------- BOOKING SUMMARY SCREEN --------------------
class BookingSummaryScreen extends StatelessWidget {
  final String name;
  final String phoneNumber;
  final String movieTitle;
  final int ticketCount;
  final double pricePerTicket;
  final double totalPrice;

  const BookingSummaryScreen({
    super.key,
    required this.name,
    required this.phoneNumber,
    required this.movieTitle,
    required this.ticketCount,
    required this.pricePerTicket,
    required this.totalPrice,
  });

  @override
  Widget build(BuildContext context) {
    final gold = Theme.of(context).colorScheme.secondary;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A1530), Color(0xFF141221), Color(0xFF1B0F16)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 5),
                Align(
                  alignment: Alignment.topLeft,
                  child: TextButton.icon(
                    onPressed: () {
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                            builder: (context) => const HomeScreen()),
                        (route) => false,
                      );
                    },
                    style: TextButton.styleFrom(
                      foregroundColor: gold,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 4, vertical: 4),
                    ),
                    icon: const Icon(Icons.home_outlined, size: 20),
                    label: const Text(
                      'Home',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [gold, const Color(0xFFB71C1C)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: gold.withOpacity(0.4),
                        blurRadius: 24,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.check_circle_outline,
                      size: 35, color: Colors.white),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Booking Confirmed!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Here is your booking summary',
                  style: TextStyle(color: Colors.white60, fontSize: 14),
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: SingleChildScrollView(
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: const Color(0xFF211D34),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: gold.withOpacity(0.3)),
                      ),
                      child: Column(
                        children: [
                          _summaryRow(Icons.person_outline, 'Name', name),
                          const Divider(color: Colors.white12, height: 20),
                          _summaryRow(Icons.phone_outlined, 'Phone Number',
                              phoneNumber),
                          const Divider(color: Colors.white12, height: 20),
                          _summaryRow(
                              Icons.local_movies_outlined, 'Movie Title', movieTitle),
                          const Divider(color: Colors.white12, height: 20),
                          _summaryRow(Icons.confirmation_num_outlined,
                              'Number of Tickets', '$ticketCount'),
                          const Divider(color: Colors.white12, height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Total Price',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'GH₵ ${totalPrice.toStringAsFixed(2)}',
                                style: TextStyle(
                                  color: gold,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // Load a fresh (refreshed) booking form page,
                      // replacing the summary screen so the form
                      // starts with empty/default fields.
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(
                          builder: (context) => const BookingFormScreen(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: gold,
                      foregroundColor: const Color(0xFF1A1530),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 6,
                    ),
                    icon: const Icon(Icons.refresh),
                    label: const Text(
                      'Book Another Ticket',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _summaryRow(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: Colors.white54, size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(color: Colors.white54, fontSize: 12)),
              const SizedBox(height: 4),
              Text(value,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ],
    );
  }
}