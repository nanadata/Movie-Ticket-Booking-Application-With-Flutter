// Widget tests for the Group 9 Cinema Bookings app.
//
// These tests exercise the Home screen, the "View Members" dialog, the
// booking form's validation rules (name, phone number, movie title,
// ticket count), and the navigation flow through to the Booking Summary
// screen.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. You can send tap and scroll gestures,
// find child widgets in the widget tree, read text, and verify that the
// values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:group_9_cinema_bookings/main.dart';

void main() {
  testWidgets('Home screen shows welcome text and action buttons',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    // Welcome text and both primary buttons should be visible.
    expect(find.textContaining('Group 9 Cinema Bookings'), findsWidgets);
    expect(find.text('Book Tickets'), findsOneWidget);
    expect(find.text('View Members'), findsOneWidget);
  });

  testWidgets('View Members button opens the members dialog',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    await tester.tap(find.text('View Members'));
    await tester.pumpAndSettle();

    // Dialog title and a couple of known members should be visible.
    expect(find.text('GROUP 9 MEMBERS'), findsOneWidget);
    expect(find.textContaining('Buabeng Otoo Derrick'), findsOneWidget);
    expect(find.textContaining('Ankrah Isaac'), findsOneWidget);

    // Closing the dialog returns to the home screen.
    await tester.tap(find.text('Close'));
    await tester.pumpAndSettle();
    expect(find.text('GROUP 9 MEMBERS'), findsNothing);
  });

  testWidgets('Book Tickets button navigates to the booking form',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    await tester.tap(find.text('Book Tickets'));
    await tester.pumpAndSettle();

    expect(find.text('Your Name'), findsOneWidget);
    expect(find.text('Phone Number'), findsOneWidget);
    expect(find.text('Movie Title'), findsOneWidget);
    expect(find.text('Number of Tickets'), findsOneWidget);
    expect(find.text('Book Ticket'), findsOneWidget);
  });

  testWidgets('Booking form validates empty fields on submit',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    await tester.tap(find.text('Book Tickets'));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Book Ticket'));
    await tester.pumpAndSettle();

    expect(find.text('Please enter your name'), findsOneWidget);
    expect(find.text('Please enter your phone number'), findsOneWidget);
    expect(find.text('Please enter or select a movie title'), findsOneWidget);
  });

  testWidgets('Name field rejects digits', (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    await tester.tap(find.text('Book Tickets'));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.widgetWithText(TextFormField, 'e.g. Derrick Buabeng Otoo').first,
      'Derrick123',
    );
    await tester.pump();

    // The input formatter strips digits, so only the letters remain.
    final field = tester
        .widget<TextFormField>(find.byType(TextFormField).first);
    expect(field.controller?.text, 'Derrick');
  });

  testWidgets('Phone number field enforces 10 digits starting with 0',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    await tester.tap(find.text('Book Tickets'));
    await tester.pumpAndSettle();

    // Fill in a valid name and movie title so only the phone number is invalid.
    await tester.enterText(
      find.widgetWithText(TextFormField, 'e.g. Derrick Buabeng Otoo'),
      'Derrick Buabeng',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'e.g. 0551736601'),
      '1551736601', // does not start with 0
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Type or pick a movie title'),
      'Students of ATU',
    );

    await tester.tap(find.text('Book Ticket'));
    await tester.pumpAndSettle();

    expect(
      find.text('Enter a valid 10-digit number starting with 0'),
      findsOneWidget,
    );
  });

  testWidgets('Ticket stepper increments and decrements within bounds',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    await tester.tap(find.text('Book Tickets'));
    await tester.pumpAndSettle();

    // Ticket count starts at 1.
    expect(find.text('1'), findsWidgets);

    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();
    expect(find.text('2'), findsWidgets);

    await tester.tap(find.byIcon(Icons.remove));
    await tester.pump();
    expect(find.text('1'), findsWidgets);
  });

  testWidgets(
      'Completing the form navigates to the Booking Summary screen with correct details',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    await tester.tap(find.text('Book Tickets'));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.widgetWithText(TextFormField, 'e.g. Derrick Buabeng Otoo'),
      'Derrick Buabeng',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'e.g. 0551736601'),
      '0551736601',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Type or pick a movie title'),
      'Students of ATU',
    );

    // Bump ticket count from 1 to 2 (2 x GH₵50.00 = GH₵100.00).
    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();

    await tester.tap(find.text('Book Ticket'));
    await tester.pumpAndSettle();

    expect(find.text('Booking Confirmed!'), findsOneWidget);
    expect(find.text('Derrick Buabeng'), findsOneWidget);
    expect(find.text('0551736601'), findsOneWidget);
    expect(find.text('Students of ATU'), findsOneWidget);
    expect(find.text('GH₵ 100.00'), findsOneWidget);
  });

  testWidgets('Home button on Booking Summary returns to the Home screen',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MovieTicketApp());

    await tester.tap(find.text('Book Tickets'));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.widgetWithText(TextFormField, 'e.g. Derrick Buabeng Otoo'),
      'Derrick Buabeng',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'e.g. 0551736601'),
      '0551736601',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Type or pick a movie title'),
      'Students of ATU',
    );

    await tester.tap(find.text('Book Ticket'));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Home'));
    await tester.pumpAndSettle();

    expect(find.text('Book Tickets'), findsOneWidget);
    expect(find.text('View Members'), findsOneWidget);
  });
}